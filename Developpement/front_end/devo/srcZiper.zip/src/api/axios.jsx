// src/api/axios.js
import axios from 'axios'

const api = axios.create({
    baseURL: import.meta.env.VITE_API_URL ?? 'http://localhost:8000/api',
    headers: {
        'Content-Type': 'application/json',
        'Accept':        'application/json',
    },
})

// ─── Request interceptor — injecte le token Bearer ────────────────────────────
api.interceptors.request.use(
    config => {
        const token = localStorage.getItem('token')
        if (token) {
            config.headers.Authorization = `Bearer ${token}`
        }
        return config
    },
    error => Promise.reject(error)
)

// ─── Response interceptor — gestion globale des erreurs ───────────────────────
api.interceptors.response.use(
    response => response,
    error => {
        const status = error.response?.status

        if (status === 401) {
            // Token expiré ou invalide → déconnexion automatique
            localStorage.removeItem('token')
            window.location.href = '/login'
        }

        if (status === 403) {
            console.error('Accès refusé')
        }

        if (status === 422) {
            // Erreurs de validation Laravel — disponibles dans error.response.data.errors
            console.error('Validation:', error.response.data.errors)
        }

        if (status >= 500) {
            console.error('Erreur serveur')
        }

        return Promise.reject(error)
    }
)

export default api